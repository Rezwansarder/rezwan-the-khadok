REZWAN THE KHADOK - Admin Website

HOW TO USE:
1. Extract the ZIP.
2. Keep index.html and the assets folder together.
3. Open index.html in Chrome/Edge.
4. Go to Admin Panel.
5. Demo password: 1234
6. Add/edit/delete food posts.

IMPORTANT:
- Posts are saved in the browser's localStorage on that computer/browser.
- This is a front-end demo admin panel, not a secure server-side CMS.
- For a public website with secure login, image uploads and a database, connect this design to a hosting/database backend.
